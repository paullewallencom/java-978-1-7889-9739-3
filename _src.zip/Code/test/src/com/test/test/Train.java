package com.test.test;

class Train {

	String name;
	String color;
	
	String running() {
		
		return "name : " +this.name +" & its "+ "Runing";
				
	}
	
	
	

	
}
