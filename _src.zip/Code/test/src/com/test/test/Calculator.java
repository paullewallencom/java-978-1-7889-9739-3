package com.test.test;

import com.test.otherpackage.Bus;

public class Calculator {

	String myName;
//	public static void main(String[] args) {
//
//		
//		
//		
//	}
}
/*Main main=new Main();
main.myName = "nilesh";
System.out.println(main.myName);

Car myCar = new Car("Honda", "Red");
myCar.fillFuel("Gas");// public method
System.out.println("my Car Details :");
System.out.println("Name: " + myCar.name);
System.out.println("Color: " + myCar.color);
System.out.println("fuel: " + myCar.fuelType);

System.out.println("Emptyinggg....");
myCar.empty();
System.out.println("fuel: " + myCar.fuelType);

System.out.println("Filling Petrol....");
myCar.fillFuel("Petrol");
System.out.println("fuel: " + myCar.fuelType);

System.out.println("---------------");
Bike myBike = new Bike("Scooty", "Silver", "GearLess");
System.out.println("my Bike Details :");
System.out.println("Name: " + myBike.name);
System.out.println("Color: " + myBike.color);
System.out.println("GearType: " + myBike.gearType);

// myBike.changeGearType("grearLess"); not able to access private method

myBike.getGearType();// as method is protected can be available in same package

System.out.println("---------------");
Bus myBus = new Bus("Tata", "Black", "normal");
System.out.println("my Bus Details :");
System.out.println("Name: " + myBus.name);
System.out.println("Color: " + myBus.color);
System.out.println("GearType: " + myBus.type);

myBus.changeBusType("DoubleDecker");

Train myTrain = new Train();
myTrain.name = "nilesh";

System.out.println("***"+myTrain.name);

myTrain.name="BBBB";
System.out.println("***"+myTrain.name);

String status = myTrain.running();

System.out.println("***"+myTrain.name);

System.out.println("status : "+status);*/