package inheritanceHierarchical;

public class Bike extends Vehicle {
	String name;
	
	public Bike(String name,String color) {
		this.name = name;
	}
	public Bike() {
	}
}
