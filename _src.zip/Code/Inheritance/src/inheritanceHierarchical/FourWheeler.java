package inheritanceHierarchical;

public class FourWheeler extends Bike{

	int noOfWheels;
	public FourWheeler() {
		noOfWheels = 4;
	}
}
