package inheritanceHierarchical;

public class Vehicle {

	String color;
}
