package inheritanceBasic;

public class Vehicle {

	String color;
}
