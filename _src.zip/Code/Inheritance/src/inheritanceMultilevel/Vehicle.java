package inheritanceMultilevel;

public class Vehicle {

	String color;
}
