package inheritanceMultilevel;

public class TwoWheeler extends Bike{

	int noOfWheels;
	public TwoWheeler() {
		noOfWheels = 2;
	}
}
