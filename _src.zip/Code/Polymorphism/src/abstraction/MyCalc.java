package abstraction;

public class MyCalc extends Calculator {

	@Override
	void add() {
		System.out.println("2 + 5 = "+2+5);
	}

}
