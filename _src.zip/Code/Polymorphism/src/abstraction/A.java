package abstraction;

public interface X {

	void a();
}

class A implements X{
	public static void main(String[] args) {
		
	}

	@Override
	public void a() {
		
	}
}