package abstraction;

public abstract class Calculator {

	abstract void add();
	
	void multiply() {
		System.out.println("2 x 5 = "+2*5);
	}
}
