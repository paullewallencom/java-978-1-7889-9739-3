package methodOverriding;

public class Vehicle {

	String color;
	void run(){
		System.out.println("Running.....!!!");
	}
}
