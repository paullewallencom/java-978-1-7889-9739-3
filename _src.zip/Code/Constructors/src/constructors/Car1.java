//Default constructor(No argument Constructor)
package constructors;

public class Car1 {

	String name;
	
	public static void main(String[] args) {

		Car1 myCar1=new Car1();
		myCar1.name = "BMW";
		System.out.println("my Car1 name : "+myCar1.name);
		
	}

}
