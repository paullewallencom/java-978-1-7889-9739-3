package exceptions;

public class UnHandledException {

	public static void main(String[] args) {

		int data = 100 / 0;  //code that may raise exception
		System.out.print("rest of the code...");
	}

}
